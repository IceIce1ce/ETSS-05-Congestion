# DPD
Code for "[Dynamic Proxy Domain Generalizes the Crowd Localization by Better Binary Segmentation](https://arxiv.org/abs/2404.13992)".

Oue code is based on [IIM](https://github.com/taohan10200/IIM).
