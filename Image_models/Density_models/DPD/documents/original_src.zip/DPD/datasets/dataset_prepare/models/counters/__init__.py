from . import Res50_SCAR
