python train.py \
    --data-dir /path/to/preprocessed/dataset \
    --save-dir /path/to/saved/model \
    --lr 1e-5 \
    --device 0
