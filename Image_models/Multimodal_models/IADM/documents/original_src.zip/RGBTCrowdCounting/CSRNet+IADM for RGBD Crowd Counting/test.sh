python test.py \
    --test test.json \
	-c /checkpoint/file