python model_fusion_train.py \
    --train train.json \
    --test test.json \
	--lr 1e-5 \
	--save /path/to/save/checkpoint