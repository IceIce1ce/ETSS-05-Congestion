from .build import loading_data

def build_dataset(cfg):
    return loading_data(cfg)