import torch
import torch.nn as nn
from .HRNet import HighResolutionNet as net

def center_crop_tensor(a, b):
    shape_a = a.shape
    shape_b = b.shape

    target_height = min(shape_a[-2], shape_b[-2])
    target_width = min(shape_a[-1], shape_b[-1])
    
    a_start_h = (shape_a[-2] - target_height) // 2
    a_start_w = (shape_a[-1] - target_width) // 2
    b_start_h = (shape_b[-2] - target_height) // 2
    b_start_w = (shape_b[-1] - target_width) // 2
    
    cropped_a = a[..., a_start_h:a_start_h + target_height, a_start_w:a_start_w + target_width]
    cropped_b = b[..., b_start_h:b_start_h + target_height, b_start_w:b_start_w + target_width]
    
    return cropped_a, cropped_b

class ObjectCounter(nn.Module):
    def __init__(self,gpus,model_name,loss_1_fn=None,loss_2_fn=None):
        super(ObjectCounter, self).__init__()        

        self.CCN = net()
        if len(gpus)>1:
            self.CCN = torch.nn.DataParallel(self.CCN, device_ids=gpus).cuda()
        else:
            self.CCN=self.CCN.cuda()

    def test_forward(self, img):                               
        density_map = self.CCN(img)                    
        return density_map

