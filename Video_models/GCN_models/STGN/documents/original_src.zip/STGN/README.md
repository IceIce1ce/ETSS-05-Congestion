# STGN

Code repository for our paper "Spatial-Temporal Graph Network for Video Crowd Counting", accepted by TCSVT.


[pretrained model](https://pan.baidu.com/s/1Tyq3LOjWQwV1eyYLeFN1Bw) (code:ekc2)  
